SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

DROP SCHEMA IF EXISTS `largegopher` ;
CREATE SCHEMA IF NOT EXISTS `largegopher` DEFAULT CHARACTER SET latin1 ;
USE `largegopher` ;

-- -----------------------------------------------------
-- Table `largegopher`.`Actor`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Actor` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Actor` (
  `A_id` INT(11) NOT NULL,
  `A_naam` VARCHAR(60) NOT NULL,
  `A_beschrijving` VARCHAR(60) NOT NULL,
  PRIMARY KEY (`A_id`),
  UNIQUE INDEX `A_id_UNIQUE` (`A_id` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`Business_Use_Case`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Business_Use_Case` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Business_Use_Case` (
  `BUC_naam` VARCHAR(45) NOT NULL,
  `BUC_id` VARCHAR(11) NOT NULL,
  `BUC_business_event` VARCHAR(150) NOT NULL,
  `BUC_trigger` VARCHAR(150) NOT NULL,
  `BUC_precondition` VARCHAR(150) NOT NULL,
  `BUC_geintereseerde_stakeholder` INT(11) NOT NULL,
  `BUC_betrokken_stakeholder` INT(11) NOT NULL,
  `BUC_stapsgewijs_beschrijving` INT(11) NOT NULL,
  `BUC_resultaat` VARCHAR(150) NOT NULL,
  PRIMARY KEY (`BUC_naam`),
  UNIQUE INDEX `BUC_naam_UNIQUE` (`BUC_naam` ASC),
  UNIQUE INDEX `BUC_id_UNIQUE` (`BUC_id` ASC),
  UNIQUE INDEX `BUC_stapsgewijs_beschrijving_UNIQUE` (`BUC_stapsgewijs_beschrijving` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`Stakeholder`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Stakeholder` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Stakeholder` (
  `SH_id` INT(11) NOT NULL,
  `SH_naam` VARCHAR(45) NOT NULL,
  `SH_beschrijving` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`SH_id`),
  UNIQUE INDEX `SH_id_UNIQUE` (`SH_id` ASC),
  UNIQUE INDEX `SH_naam_UNIQUE` (`SH_naam` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`BUC_Betrokken_Stakeholder`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`BUC_Betrokken_Stakeholder` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`BUC_Betrokken_Stakeholder` (
  `BUCBS_id` INT(11) NOT NULL,
  `BUCBS_stakeholder` INT(11) NOT NULL,
  `BUCBS_BUC_id` VARCHAR(11) NOT NULL,
  PRIMARY KEY (`BUCBS_id`),
  UNIQUE INDEX `BUCBSH_id_UNIQUE` (`BUCBS_id` ASC),
  INDEX `BUCBS_BUC_fk_idx` (`BUCBS_BUC_id` ASC),
  INDEX `BUCBS_SH_fk_idx` (`BUCBS_stakeholder` ASC),
  CONSTRAINT `BUCBS_BUC_fk`
    FOREIGN KEY (`BUCBS_BUC_id`)
    REFERENCES `largegopher`.`Business_Use_Case` (`BUC_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `BUCBS_SH_fk`
    FOREIGN KEY (`BUCBS_stakeholder`)
    REFERENCES `largegopher`.`Stakeholder` (`SH_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`BUC_Geintereseerde_Stakeholder`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`BUC_Geintereseerde_Stakeholder` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`BUC_Geintereseerde_Stakeholder` (
  `BUCGS_id` INT(11) NOT NULL,
  `BUCGS_stakeholder` INT(11) NOT NULL,
  `BUCGS_BUC_id` VARCHAR(11) NOT NULL,
  PRIMARY KEY (`BUCGS_id`),
  UNIQUE INDEX `BUCGS_id_UNIQUE` (`BUCGS_id` ASC),
  INDEX `BUCGS_BUC_fk_idx` (`BUCGS_BUC_id` ASC),
  INDEX `BUCGS_SH_fk_idx` (`BUCGS_stakeholder` ASC),
  CONSTRAINT `BUCGS_BUC_fk`
    FOREIGN KEY (`BUCGS_BUC_id`)
    REFERENCES `largegopher`.`Business_Use_Case` (`BUC_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `BUCGS_SH_fk`
    FOREIGN KEY (`BUCGS_stakeholder`)
    REFERENCES `largegopher`.`Stakeholder` (`SH_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`BUC_Stapsgewijs_Beschrijving`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`BUC_Stapsgewijs_Beschrijving` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`BUC_Stapsgewijs_Beschrijving` (
  `SB_id` INT(11) NOT NULL,
  `SB_stap_id` VARCHAR(45) NOT NULL,
  `SB_stap_beschrijving` VARCHAR(150) NOT NULL,
  INDEX `SB_BUC_fk_idx` (`SB_id` ASC),
  CONSTRAINT `SB_BUC_fk`
    FOREIGN KEY (`SB_id`)
    REFERENCES `largegopher`.`Business_Use_Case` (`BUC_stapsgewijs_beschrijving`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`Catagorie`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Catagorie` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Catagorie` (
  `cat_naam` VARCHAR(45) NOT NULL,
  `cat_beschrijving` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cat_naam`),
  UNIQUE INDEX `cat_beschrijving_UNIQUE` (`cat_naam` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`Functie`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Functie` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Functie` (
  `fun_naam` VARCHAR(45) NOT NULL,
  `fun_beschrijving` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`fun_naam`),
  UNIQUE INDEX `fun_beschrijving_UNIQUE` (`fun_naam` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`Product_Use_Case`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Product_Use_Case` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Product_Use_Case` (
  `PUC_naam` VARCHAR(45) NOT NULL,
  `PUC_id` VARCHAR(11) NOT NULL,
  `BUC_naam` VARCHAR(100) NULL DEFAULT NULL,
  `BUC_id` VARCHAR(11) NULL DEFAULT NULL,
  `PUC_trigger` VARCHAR(150) NOT NULL,
  `PUC_preconditie` VARCHAR(150) NOT NULL,
  `PUC_shareholders` INT(11) NOT NULL,
  `PUC_actoren` INT(11) NOT NULL,
  `PUC_stapsgewijs_beschrijving` INT(11) NOT NULL,
  `PUC_resultaat` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`PUC_naam`),
  UNIQUE INDEX `PUC_naam_UNIQUE` (`PUC_naam` ASC),
  UNIQUE INDEX `PUC_id_UNIQUE` (`PUC_id` ASC),
  UNIQUE INDEX `PUC_stapsgewijs_beschrijving_UNIQUE` (`PUC_stapsgewijs_beschrijving` ASC),
  UNIQUE INDEX `PUC_actoren_UNIQUE` (`PUC_actoren` ASC),
  INDEX `PUC_BUC_fk_idx` (`BUC_naam` ASC),
  INDEX `PUC_BUC_id_fk_idx` (`BUC_id` ASC),
  CONSTRAINT `PUC_BUC_fk`
    FOREIGN KEY (`BUC_naam`)
    REFERENCES `largegopher`.`Business_Use_Case` (`BUC_naam`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `PUC_BUC_id_fk`
    FOREIGN KEY (`BUC_id`)
    REFERENCES `largegopher`.`Business_Use_Case` (`BUC_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`PUC_Actoren`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`PUC_Actoren` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`PUC_Actoren` (
  `PUCA_id` INT(11) NOT NULL,
  `PUCA_PUC_id` VARCHAR(11) NOT NULL,
  `PUCA_A_id` INT(11) NOT NULL,
  PRIMARY KEY (`PUCA_id`),
  UNIQUE INDEX `PUCA_id_UNIQUE` (`PUCA_id` ASC),
  INDEX `PUCA_PUC_fk_idx` (`PUCA_PUC_id` ASC),
  INDEX `PUCA_A_fk_idx` (`PUCA_A_id` ASC),
  INDEX `PUCA_A_fk_idx1` (`PUCA_A_id` ASC),
  CONSTRAINT `PUCA_A_fk`
    FOREIGN KEY (`PUCA_A_id`)
    REFERENCES `largegopher`.`Actor` (`A_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `PUCA_PUC_fk`
    FOREIGN KEY (`PUCA_PUC_id`)
    REFERENCES `largegopher`.`Product_Use_Case` (`PUC_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`PUC_Stakeholder`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`PUC_Stakeholder` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`PUC_Stakeholder` (
  `PUCS_id` INT(11) NOT NULL,
  `PUCS_PUC_id` VARCHAR(11) NOT NULL,
  `PUCS_stakeholder` INT(11) NOT NULL,
  PRIMARY KEY (`PUCS_id`),
  UNIQUE INDEX `PUCS_id_UNIQUE` (`PUCS_id` ASC),
  INDEX `PUCS_PUC_fk_idx` (`PUCS_PUC_id` ASC),
  INDEX `PUCS_SH_fk_idx` (`PUCS_stakeholder` ASC),
  CONSTRAINT `PUCS_PUC_fk`
    FOREIGN KEY (`PUCS_PUC_id`)
    REFERENCES `largegopher`.`Product_Use_Case` (`PUC_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `PUCS_SH_fk`
    FOREIGN KEY (`PUCS_stakeholder`)
    REFERENCES `largegopher`.`Stakeholder` (`SH_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`PUC_Stapsgewijs_Beschrijving`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`PUC_Stapsgewijs_Beschrijving` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`PUC_Stapsgewijs_Beschrijving` (
  `SB_id` INT(11) NOT NULL,
  `SB_stap_id` VARCHAR(45) NOT NULL,
  `SB_stap_beschrijving` VARCHAR(150) NOT NULL,
  INDEX `SB_BUC_fk_idx` (`SB_id` ASC),
  CONSTRAINT `SB_PUC_fk`
    FOREIGN KEY (`SB_id`)
    REFERENCES `largegopher`.`Product_Use_Case` (`PUC_stapsgewijs_beschrijving`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`Prioriteit`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Prioriteit` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Prioriteit` (
  `pri_naam` VARCHAR(45) NOT NULL,
  `pri_beschrijving` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`pri_naam`),
  UNIQUE INDEX `pri_beschrijving_UNIQUE` (`pri_naam` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`Status`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Status` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Status` (
  `sta_naam` VARCHAR(45) NOT NULL,
  `sta_beschrijving` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`sta_naam`),
  UNIQUE INDEX `sta_naam_UNIQUE` (`sta_naam` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`Requirement`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Requirement` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Requirement` (
  `req_ID` VARCHAR(11) NOT NULL,
  `req_beschrijving` VARCHAR(150) NOT NULL,
  `req_catagorie` VARCHAR(45) NOT NULL,
  `req_functie` VARCHAR(45) NOT NULL,
  `req_status` VARCHAR(45) NOT NULL,
  `req_prioriteit` VARCHAR(45) NOT NULL,
  `req_BUC` VARCHAR(11) NULL DEFAULT NULL,
  `req_PUC` VARCHAR(11) NULL DEFAULT NULL,
  `req_rationale` VARCHAR(45) NULL DEFAULT NULL,
  `req_bedenker` VARCHAR(45) NOT NULL,
  `req_customer_satisfaction` INT(11) NULL DEFAULT NULL,
  `req_customer_dissatisfaction` INT(11) NULL DEFAULT NULL,
  `req_conflicten` VARCHAR(11) NULL DEFAULT NULL,
  `req_is_subreq_van` VARCHAR(11) NULL DEFAULT NULL,
  PRIMARY KEY (`req_ID`),
  UNIQUE INDEX `req_ID_UNIQUE` (`req_ID` ASC),
  INDEX `req_fun_idx` (`req_functie` ASC),
  INDEX `req_sta_idx` (`req_status` ASC),
  INDEX `req_cat_idx` (`req_catagorie` ASC),
  INDEX `req_pri_idx` (`req_prioriteit` ASC),
  INDEX `req_BUC-fk_idx` (`req_BUC` ASC),
  INDEX `req_PUC1_fk_idx` (`req_PUC` ASC),
  INDEX `req_req_1_fk_idx` (`req_is_subreq_van` ASC),
  INDEX `req_rc_fk_idx` (`req_conflicten` ASC),
  INDEX `req_buc_fk_idx` (`req_BUC` ASC),
  INDEX `req_puc_fk_idx` (`req_PUC` ASC),
  CONSTRAINT `req_buc_fk`
    FOREIGN KEY (`req_BUC`)
    REFERENCES `largegopher`.`Business_Use_Case` (`BUC_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `req_cat_fk`
    FOREIGN KEY (`req_catagorie`)
    REFERENCES `largegopher`.`Catagorie` (`cat_naam`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `req_fun_fk`
    FOREIGN KEY (`req_functie`)
    REFERENCES `largegopher`.`Functie` (`fun_naam`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `req_pri_fk`
    FOREIGN KEY (`req_prioriteit`)
    REFERENCES `largegopher`.`Prioriteit` (`pri_naam`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `req_puc_fk`
    FOREIGN KEY (`req_PUC`)
    REFERENCES `largegopher`.`Product_Use_Case` (`PUC_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `req_req_1_fk`
    FOREIGN KEY (`req_is_subreq_van`)
    REFERENCES `largegopher`.`Requirement` (`req_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `req_sta_fk`
    FOREIGN KEY (`req_status`)
    REFERENCES `largegopher`.`Status` (`sta_naam`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `largegopher`.`Requirement_Conflict`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `largegopher`.`Requirement_Conflict` ;

CREATE TABLE IF NOT EXISTS `largegopher`.`Requirement_Conflict` (
  `RC_id` VARCHAR(11) NOT NULL,
  `RC_Requirement_id` VARCHAR(11) NOT NULL,
  `RC_Conflict_Requirement` VARCHAR(11) NOT NULL,
  PRIMARY KEY (`RC_id`),
  UNIQUE INDEX `RC_id_UNIQUE` (`RC_id` ASC),
  INDEX `rc_req_fk_idx` (`RC_Requirement_id` ASC),
  INDEX `rc_req_2_fk_idx` (`RC_Conflict_Requirement` ASC),
  CONSTRAINT `rc_req_2_fk`
    FOREIGN KEY (`RC_Conflict_Requirement`)
    REFERENCES `largegopher`.`Requirement` (`req_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `rc_req_fk`
    FOREIGN KEY (`RC_Requirement_id`)
    REFERENCES `largegopher`.`Requirement` (`req_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
