-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 27 okt 2013 om 19:34
-- Serverversie: 5.5.31
-- PHP-Versie: 5.4.4-14+deb7u5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `largegopher`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Actor`
--

CREATE TABLE IF NOT EXISTS `Actor` (
  `A_id` int(11) NOT NULL,
  `A_naam` varchar(60) NOT NULL,
  `A_beschrijving` varchar(60) NOT NULL,
  PRIMARY KEY (`A_id`),
  UNIQUE KEY `A_id_UNIQUE` (`A_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `Actor`
--

INSERT INTO `Actor` (`A_id`, `A_naam`, `A_beschrijving`) VALUES
(1, 'Projectdocent', 'Docent van een project dat de barometer gebruikt'),
(2, 'Student', 'Diegene die het project uitvoert'),
(3, 'Tutor', 'Docent die het groep begeleid'),
(4, 'Mentor', 'Begeleider van de student');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `BUC_Betrokken_Stakeholder`
--

CREATE TABLE IF NOT EXISTS `BUC_Betrokken_Stakeholder` (
  `BUCBS_id` int(11) NOT NULL,
  `BUCBS_stakeholder` int(11) NOT NULL,
  `BUCBS_BUC_id` varchar(11) NOT NULL,
  PRIMARY KEY (`BUCBS_id`),
  UNIQUE KEY `BUCBSH_id_UNIQUE` (`BUCBS_id`),
  KEY `BUCBS_BUC_fk_idx` (`BUCBS_BUC_id`),
  KEY `BUCBS_SH_fk_idx` (`BUCBS_stakeholder`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `BUC_Betrokken_Stakeholder`
--

INSERT INTO `BUC_Betrokken_Stakeholder` (`BUCBS_id`, `BUCBS_stakeholder`, `BUCBS_BUC_id`) VALUES
(1, 3, '1'),
(2, 1, '2'),
(3, 2, '3'),
(4, 5, '4');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `BUC_Geintereseerde_Stakeholder`
--

CREATE TABLE IF NOT EXISTS `BUC_Geintereseerde_Stakeholder` (
  `BUCGS_id` int(11) NOT NULL,
  `BUCGS_stakeholder` int(11) NOT NULL,
  `BUCGS_BUC_id` varchar(11) NOT NULL,
  PRIMARY KEY (`BUCGS_id`),
  UNIQUE KEY `BUCGS_id_UNIQUE` (`BUCGS_id`),
  KEY `BUCGS_BUC_fk_idx` (`BUCGS_BUC_id`),
  KEY `BUCGS_SH_fk_idx` (`BUCGS_stakeholder`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `BUC_Geintereseerde_Stakeholder`
--

INSERT INTO `BUC_Geintereseerde_Stakeholder` (`BUCGS_id`, `BUCGS_stakeholder`, `BUCGS_BUC_id`) VALUES
(1, 1, '1'),
(2, 2, '1'),
(3, 1, '2'),
(4, 4, '2'),
(5, 5, '2'),
(6, 1, '3'),
(7, 4, '3'),
(8, 6, '3'),
(9, 1, '4');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `BUC_Stapsgewijs_Beschrijving`
--

CREATE TABLE IF NOT EXISTS `BUC_Stapsgewijs_Beschrijving` (
  `SB_id` int(11) NOT NULL,
  `SB_stap_id` varchar(45) NOT NULL,
  `SB_stap_beschrijving` varchar(150) NOT NULL,
  KEY `SB_BUC_fk_idx` (`SB_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `BUC_Stapsgewijs_Beschrijving`
--

INSERT INTO `BUC_Stapsgewijs_Beschrijving` (`SB_id`, `SB_stap_id`, `SB_stap_beschrijving`) VALUES
(1, '1', 'De projectdocent kijkt of het project al eens eerder is gedaan'),
(1, '2', 'Zo ja, dan neemt hij de beoordelingscriteria template over van dat project '),
(1, '3', 'Zo nee, dan maakt hij een nieuwe beoordelingscriteria template'),
(1, '4', 'De projectdocent kijkt of de beoordelingscriteria punten goed staan geformuleerd'),
(1, '5', 'Waar nodig wijzigt hij de punten'),
(1, '6', 'De Projectdocent stelt de beoordelings datums vast'),
(1, '7', 'De Projectdocent kijkt of de groepsindeling met studenten en tutoren al bekend is gemaakt door de blok coordinator en inzetter'),
(1, '8', 'Zo ja, dan voegt hij deze toe.'),
(1, '9', 'Zo nee, dan voegt hij deze toe zodra die bekend is gemaakt'),
(2, '1', 'De student pakt het groepsbeoordelingsmiddel erbij '),
(2, '2', 'De student kiest de huidige student die hij/zij wil gaan beoordelen van zijn  groep.'),
(2, '3', 'De student vult het beoordelingsmiddel in aan de hand van zijn mening.'),
(2, '4', 'De student controleert of alles goed is beoordeeld'),
(2, '5', 'De student bevestigt zijn beoordeling.'),
(2, '6', 'Dit proces wordt herhaald totdat de student al zijn medestudenten heeft beoordeeld.'),
(3, '1', 'De tutor verzamelt alle gegevens van de studenten van zijn/haar groep met betrekking tot het beoordelingsmiddel.'),
(3, '2', 'De tutor kiest een student om te beoordelen.'),
(3, '3', 'De tutor bekijkt per onderwerp hoe de student beoordeeld is.'),
(3, '4', 'De tutor bekijkt alle beoordelingen van het laatste beoordelingsmoment.'),
(3, '5', 'De tutor vergelijkt de beoordeling met de beoordelingen die zijn gegeven door de medestudenten.'),
(3, '6', 'De tutor kijkt of die overeenkomt met zijn/haar eigen waarnemingen.'),
(3, '7', 'Als dit niet overeenkomt dan kijkt de tutor in de voorgaande weken van het beoordelingsmiddel'),
(3, '8', 'Met de hieruit teruggegeven informatie bepaalt de tutor de eindbeoordeling.'),
(3, '9', 'Als de waarneming wel overeenkomt, bepaalt de tutor de eindbeoordeling door middel van de norm.'),
(3, '10', 'Dit proces wordt herhaald voor elke student in de desbetreffende groep'),
(4, '1', 'De mentor bedenkt wat die allemaal precies wil weten van zijn student.'),
(4, '2', 'De Mentor vraagt de desbetreffende beoordelingsmiddelen van de student op.'),
(4, '3', 'De beoordelingsmiddelen worden bij elkaar gehaald en vergeleken'),
(4, '4', 'Door het vergelijken van deze beoordelingsmiddellen kan de mentor een beeld uitbrengen over de voortgang van de student.');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Business_Use_Case`
--

CREATE TABLE IF NOT EXISTS `Business_Use_Case` (
  `BUC_naam` varchar(45) NOT NULL,
  `BUC_id` varchar(11) NOT NULL,
  `BUC_business_event` varchar(150) NOT NULL,
  `BUC_trigger` varchar(150) NOT NULL,
  `BUC_precondition` varchar(150) NOT NULL,
  `BUC_geintereseerde_stakeholder` int(11) NOT NULL,
  `BUC_betrokken_stakeholder` int(11) NOT NULL,
  `BUC_stapsgewijs_beschrijving` int(11) NOT NULL,
  `BUC_resultaat` varchar(150) NOT NULL,
  PRIMARY KEY (`BUC_naam`),
  UNIQUE KEY `BUC_naam_UNIQUE` (`BUC_naam`),
  UNIQUE KEY `BUC_id_UNIQUE` (`BUC_id`),
  UNIQUE KEY `BUC_stapsgewijs_beschrijving_UNIQUE` (`BUC_stapsgewijs_beschrijving`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `Business_Use_Case`
--

INSERT INTO `Business_Use_Case` (`BUC_naam`, `BUC_id`, `BUC_business_event`, `BUC_trigger`, `BUC_precondition`, `BUC_geintereseerde_stakeholder`, `BUC_betrokken_stakeholder`, `BUC_stapsgewijs_beschrijving`, `BUC_resultaat`) VALUES
('Eindbeoordeling', '3', 'Eindbeoordelingsmoment is aangebroken', 'Ingevulde studenten beoordelingsmiddelen, eigen waarneming van tutor.', '', 3, 3, 3, 'Elke student van de desbetreffende groep is beoordeeld.'),
('Historisch overzicht', '4', 'Studenteninformatie wordt verzocht door Mentor', 'Gegevens van de studenten', ' ', 4, 4, 4, 'Er is succesvol een historisch overzicht aangemaakt'),
('Project voorbereiden', '1', 'Het is tijd om het project voor te bereiden', 'Tijd', 'De project eind en begin datums zijn bekend', 1, 1, 1, 'Het project is succesvol aangemaakt en de deadlines zijn bepaald'),
('Tussenbeoordeling', '2', 'Beoordelingsmoment is aangebroken', 'Aantekeningen van de studenten die de student wil gaan beoordelen.', 'Er is een groepsbeoordelingsmiddel aangemaakt', 2, 2, 2, 'De beoordeling is opgeslagen en verzonden');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Catagorie`
--

CREATE TABLE IF NOT EXISTS `Catagorie` (
  `cat_naam` varchar(45) NOT NULL,
  `cat_beschrijving` varchar(45) NOT NULL,
  PRIMARY KEY (`cat_naam`),
  UNIQUE KEY `cat_beschrijving_UNIQUE` (`cat_naam`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `Catagorie`
--

INSERT INTO `Catagorie` (`cat_naam`, `cat_beschrijving`) VALUES
('Functional', 'Functioneel Req'),
('Non-Functional', 'Niet Functioneel Req'),
('Technical', 'Technisch');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Functie`
--

CREATE TABLE IF NOT EXISTS `Functie` (
  `fun_naam` varchar(45) NOT NULL,
  `fun_beschrijving` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`fun_naam`),
  UNIQUE KEY `fun_beschrijving_UNIQUE` (`fun_naam`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `Functie`
--

INSERT INTO `Functie` (`fun_naam`, `fun_beschrijving`) VALUES
('Unknown', 'niet bekend.');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Prioriteit`
--

CREATE TABLE IF NOT EXISTS `Prioriteit` (
  `pri_naam` varchar(45) NOT NULL,
  `pri_beschrijving` varchar(45) NOT NULL,
  PRIMARY KEY (`pri_naam`),
  UNIQUE KEY `pri_beschrijving_UNIQUE` (`pri_naam`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `Prioriteit`
--

INSERT INTO `Prioriteit` (`pri_naam`, `pri_beschrijving`) VALUES
('Hoog', 'Hoge Prioriteit'),
('Laag', 'Lage Prioriteit'),
('Middel', 'Middel Prioriteit');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Product_Use_Case`
--

CREATE TABLE IF NOT EXISTS `Product_Use_Case` (
  `PUC_naam` varchar(150) NOT NULL,
  `PUC_id` varchar(11) NOT NULL,
  `BUC_naam` varchar(100) DEFAULT NULL,
  `BUC_id` varchar(11) DEFAULT NULL,
  `PUC_trigger` varchar(150) NOT NULL,
  `PUC_preconditie` varchar(150) NOT NULL,
  `PUC_shareholders` int(11) NOT NULL,
  `PUC_actoren` int(11) NOT NULL,
  `PUC_stapsgewijs_beschrijving` int(11) NOT NULL,
  `PUC_resultaat` varchar(100) NOT NULL,
  PRIMARY KEY (`PUC_naam`),
  UNIQUE KEY `PUC_naam_UNIQUE` (`PUC_naam`),
  UNIQUE KEY `PUC_id_UNIQUE` (`PUC_id`),
  UNIQUE KEY `PUC_stapsgewijs_beschrijving_UNIQUE` (`PUC_stapsgewijs_beschrijving`),
  UNIQUE KEY `PUC_actoren_UNIQUE` (`PUC_actoren`),
  KEY `PUC_BUC_fk_idx` (`BUC_naam`),
  KEY `PUC_BUC_id_fk_idx` (`BUC_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `Product_Use_Case`
--

INSERT INTO `Product_Use_Case` (`PUC_naam`, `PUC_id`, `BUC_naam`, `BUC_id`, `PUC_trigger`, `PUC_preconditie`, `PUC_shareholders`, `PUC_actoren`, `PUC_stapsgewijs_beschrijving`, `PUC_resultaat`) VALUES
('De beoordelingen worden verzameld', '4.1', 'Historisch overzicht', '4', 'Identificatie van de student (bijvoorbeeld studentnummer)', 'Een student heeft een (of meer) beoordelingen', 5, 5, 5, 'Het systeem heeft succesvol de beoordelingen '),
('Een eindbeoordeling geven aan een student door de tutor.', '3.1', 'Eindbeoordeling', '3', 'De ingevulde barometers van de student', 'De gegeven student zijn/haar barometer is bijgewerkt tot en met de laatste week. De tutor is ingelogd.', 4, 4, 4, 'Alle studenten zijn succesvol beoordeeld.'),
('Goepsindeling toevoegen aan project', '1.3', 'Project voorbereiden', '1', 'Groepsindeling Excel lijst', 'De inzet co?rdinator en de blok co?rdinator hebben een definitieve groepsindeling', 11, 7, 7, 'Groepsindeling is toegevoegd aan een project. De studenten weten in welke project groep ze zitten en'),
('Historisch overzicht wordt opgevraagd', '4.2', 'Historisch overzicht', '4', 'Verzamelde beoordelingen van een student', 'Er zijn meerdere beoordelingen ingevuld', 6, 6, 6, 'Het systeem heeft het historisch overzicht van de student weergegeven'),
('Nieuw project aanmaken', '1.1', 'Project voorbereiden', '1', 'Tijd', 'De project datums zijn bekend(begin datum, eind datum) en de beoordelings momenten', 1, 1, 1, 'Er is een nieuw project aangemaakt in het systeem'),
('Nieuwe beoordelingscriteria template aanmaken', '1.2', 'Project voorbereiden', '1', 'Aantekeningen met belangrijke punten die van toepassing zijn op dit project.', 'Het is de eerste keer dat dit project wordt gehouden.', 2, 2, 2, 'Een nieuwe beoordelingscriteria template is aangemaakt en kan worden gebruikt voor projecten.'),
('Tussenbeoordeling invullen', '2.1', 'Tussenbeoordeling', '2', 'De Beoordeling van de student', 'Er is een beoordelingsmiddel beschikbaar', 3, 3, 3, 'De beoordeling is opgeslagen en vergrendeld.');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `PUC_Actoren`
--

CREATE TABLE IF NOT EXISTS `PUC_Actoren` (
  `PUCA_id` int(11) NOT NULL,
  `PUCA_PUC_id` varchar(11) NOT NULL,
  `PUCA_A_id` int(11) NOT NULL,
  PRIMARY KEY (`PUCA_id`),
  UNIQUE KEY `PUCA_id_UNIQUE` (`PUCA_id`),
  KEY `PUCA_PUC_fk_idx` (`PUCA_PUC_id`),
  KEY `PUCA_A_fk_idx` (`PUCA_A_id`),
  KEY `PUCA_A_fk_idx1` (`PUCA_A_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `PUC_Actoren`
--

INSERT INTO `PUC_Actoren` (`PUCA_id`, `PUCA_PUC_id`, `PUCA_A_id`) VALUES
(1, '1.1', 1),
(2, '1.2', 1),
(3, '2.1', 2),
(4, '3.1', 3),
(5, '4.1', 4),
(6, '4.2', 3),
(7, '1.3', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `PUC_Stakeholder`
--

CREATE TABLE IF NOT EXISTS `PUC_Stakeholder` (
  `PUCS_id` int(11) NOT NULL,
  `PUCS_PUC_id` varchar(11) NOT NULL,
  `PUCS_stakeholder` int(11) NOT NULL,
  PRIMARY KEY (`PUCS_id`),
  UNIQUE KEY `PUCS_id_UNIQUE` (`PUCS_id`),
  KEY `PUCS_PUC_fk_idx` (`PUCS_PUC_id`),
  KEY `PUCS_SH_fk_idx` (`PUCS_stakeholder`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `PUC_Stakeholder`
--

INSERT INTO `PUC_Stakeholder` (`PUCS_id`, `PUCS_PUC_id`, `PUCS_stakeholder`) VALUES
(1, '1.1', 1),
(2, '1.1', 2),
(3, '1.2', 1),
(4, '1.2', 2),
(5, '2.1', 1),
(6, '2.1', 1),
(7, '3.1', 1),
(8, '3.1', 2),
(9, '4.1', 5),
(10, '4.2', 3),
(11, '1.3', 1),
(12, '1.3', 2);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `PUC_Stapsgewijs_Beschrijving`
--

CREATE TABLE IF NOT EXISTS `PUC_Stapsgewijs_Beschrijving` (
  `SB_id` int(11) NOT NULL,
  `SB_stap_id` varchar(45) NOT NULL,
  `SB_stap_beschrijving` varchar(150) NOT NULL,
  KEY `SB_BUC_fk_idx` (`SB_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `PUC_Stapsgewijs_Beschrijving`
--

INSERT INTO `PUC_Stapsgewijs_Beschrijving` (`SB_id`, `SB_stap_id`, `SB_stap_beschrijving`) VALUES
(1, '1', 'De projectdocent kiest voor het aanmaken van een nieuw project'),
(1, '2', 'Het systeem laat een formulier zien waarin de informatie over het project kan worden ingevuld.'),
(1, '3', 'De projectdocent vult de project informatie in. (Naam van het project, Begin-eind datum, beoordelings momenten)'),
(1, '4', 'De projectdocent kiest een bestaande beoordelinscriteria template. Of hij maakt eennieuwe (->PUC 1.2)'),
(1, '5', 'De projectdocent kijkt of de groepsindeling al bekend is.'),
(1, '6', 'Zo ja, dan upload hij deze.'),
(1, '7', 'Zo nee, dan kan hij deze later toevoegen (-> PUC 1.3)'),
(1, '8', 'De project docent verzend het formulier.'),
(1, '9', 'Het systeem controleert de gegevens en maakt het nieuwe project aan.'),
(2, '1', 'Maak nieuw beoordelings template aan'),
(2, '2', 'Toon skeleton template formulier'),
(2, '3', 'Vul template met beoordelingscriteria punten'),
(2, '4', 'Verstuur formulier'),
(4, '1', 'De tutor selecteert een student'),
(4, '2', 'Het product brengt het relevante beoordelingsmiddel tevoorschijn'),
(4, '3', 'Het product laat de beoordeling van de laatste week zien'),
(4, '4', 'De tutor kijkt of de gegevens overeenkomen met zijn/haar eigen waarnemingen'),
(4, '5', 'Als de waarneming niet klopt vraagt de tutor gegevens op van de voorgaande weken'),
(4, '6', 'Het product geeft beoordelingen weer van de voorgaande weken'),
(4, '7', 'De tutor beeordeeld student'),
(4, '8', 'Het product geeft beoordelingen weer van de voorgaande weken'),
(4, '9', 'Als alle studenten nog niet zijn nagegaan geeft het product dit aan met een melding'),
(4, '10', 'Als alle studenten  zijn nagegaan geeft het product dit aan met een melding'),
(4, '11', 'Tutor sluit het product'),
(3, '1', 'De student selecteert de huidige barometer'),
(3, '2', 'Het product brengt het relevante beoordelingsmiddel tevoorschijn'),
(3, '3', 'Het product geeft een overzicht terug van studenten in de groep'),
(3, '4', 'De student bepaalt wekle beoordeling die wilt geven'),
(3, '5', 'De student voert zijn beoordeling in'),
(3, '6', 'Het systeem controleert de invoer'),
(3, '7', 'Als deze niet goed is geeft het systeem een foutmelding terug'),
(3, '8', 'Als deze wel goed is wordt het goedgekeurd'),
(3, '9', 'Student bevestigd beoordeling'),
(3, '11', 'Systeem slaat de beoordeling op'),
(5, '1', 'De mentor vraagt de beoordelingen op van student ''x'''),
(5, '2', 'het systeem zoekt student ''x'''),
(5, '3', 'Als de student niet is gevonden geeft de systeem een foutmelding'),
(5, '4', 'Als de student wel is gevonden haalt het systeem alle beoordelingen op van student ''x'''),
(5, '5', 'Het systeem geeft alle opgehaalde beoordelingen in een totaaloverzicht weer'),
(6, '1', 'Mentor vraagt een historisch overzicht op van student ''x'''),
(6, '2', 'Systeem zoekt student ''x'''),
(6, '3', 'Als deze niet gevonden is geeft het systeem een foutmelding'),
(6, '4', 'Als deze wel gevonden is loopt het systeem alle beoordelingen door van student ''x'''),
(6, '5', 'Het systeem slaat alle gegevens op in een excel bestand'),
(6, '6', 'Het system plaatst een link voor het ophalen van het Excel-bestand'),
(6, '7', 'Het systeem tekent de verzameling in een overzicht'),
(6, '8', 'Het systeem geeft het  historisch overzicht weer'),
(7, '1', 'De projectdocent klikt op project overzicht'),
(7, '2', 'Systeem laad alle projecten'),
(7, '3', 'Systeem geeft dit weer in een overzicht'),
(7, '4', 'De projectdocent selecteert het juiste project waarin die de groepsindeling wilt toevoegen'),
(7, '5', 'System geeft de geselecteerde project weer'),
(7, '6', 'De projectdocent klikt op groepen invoegen'),
(7, '7', 'Systeem vraagt om excel sheet'),
(7, '8', 'Project docent selecteert excel sheet'),
(7, '9', 'Systeem controleert excel sheet op format fouten'),
(7, '10', 'Als deze fouten heeft geeft de systeem dit aan '),
(7, '11', 'Als er geen fouten zijn voegt het systeem groepen toe aan de barometer'),
(7, '12', 'Systeem geeft melding aan dat de upload succesvol was');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Requirement`
--

CREATE TABLE IF NOT EXISTS `Requirement` (
  `req_ID` varchar(11) NOT NULL,
  `req_beschrijving` varchar(150) NOT NULL,
  `req_catagorie` varchar(45) NOT NULL,
  `req_functie` varchar(45) NOT NULL,
  `req_status` varchar(45) NOT NULL,
  `req_prioriteit` varchar(45) NOT NULL,
  `req_BUC` varchar(11) DEFAULT NULL,
  `req_PUC` varchar(11) DEFAULT NULL,
  `req_rationale` varchar(45) DEFAULT NULL,
  `req_bedenker` varchar(45) NOT NULL,
  `req_customer_satisfaction` int(11) DEFAULT NULL,
  `req_customer_dissatisfaction` int(11) DEFAULT NULL,
  `req_conflicten` varchar(11) DEFAULT NULL,
  `req_is_subreq_van` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`req_ID`),
  UNIQUE KEY `req_ID_UNIQUE` (`req_ID`),
  KEY `req_fun_idx` (`req_functie`),
  KEY `req_sta_idx` (`req_status`),
  KEY `req_cat_idx` (`req_catagorie`),
  KEY `req_pri_idx` (`req_prioriteit`),
  KEY `req_BUC-fk_idx` (`req_BUC`),
  KEY `req_PUC1_fk_idx` (`req_PUC`),
  KEY `req_req_1_fk_idx` (`req_is_subreq_van`),
  KEY `req_rc_fk_idx` (`req_conflicten`),
  KEY `req_buc_fk_idx` (`req_BUC`),
  KEY `req_puc_fk_idx` (`req_PUC`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `Requirement`
--

INSERT INTO `Requirement` (`req_ID`, `req_beschrijving`, `req_catagorie`, `req_functie`, `req_status`, `req_prioriteit`, `req_BUC`, `req_PUC`, `req_rationale`, `req_bedenker`, `req_customer_satisfaction`, `req_customer_dissatisfaction`, `req_conflicten`, `req_is_subreq_van`) VALUES
('0.1', 'Beoordelingen kunnen aangepast worden als ze al bevestigd zijn', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.11', 'Het systeem heeft een optie om studenten elkaar <<anoniem>> te laten beoordelen', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.11.1', 'Anoniem: De beoordeelde student kan niet zien van welke student een beoordeling komt', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.11'),
('0.12', 'Het systeem kan indien gewenst gebruikersgegevens voor het inloggen onthouden', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.12.1', 'Het systeem kan je wachtwoord bij inloggen onthouden', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.12'),
('0.12.2', 'Het systeem kan je gebruikersnaam bij inloggen onthouden', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.12'),
('0.13', 'Als je je wachtwoord vergeten bent kun je dit aangeven bij het inlogscherm', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.13.1', 'Het systeem weergeeft een aparte pagina hiervoor', 'Non-Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.13'),
('0.13.1.1', 'Deze pagina accepteert gebruikersnamen op deze pagina', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.13.1'),
('0.13.1.2', 'Het systeem stuurt op bevestiging een mailtje naar het emailadres dat aan deze gebruiker gekoppeld is met het wachtwoord', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.13.1'),
('0.14', 'Het systeem mag niet te veel ruimte in beslag nemen', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.15', 'Het systeem maakt gebruik van een kleine cache', 'Technical', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.16', 'Het systeem kan zichzelf automatisch herstellen als het crasht', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.17', 'De packets kunnen niet uitgelezen worden door derden', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.18', 'Er word gebruik gemaakt van SSL', 'Technical', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.19', 'Gebruikersgegevens worden niet opgeslagen op de computer van de gebruiker', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.20.', 'Het wachtwoordveld kan niet uitgelezen worden door de gebruiker', 'Non-Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.21', 'Het systeem slaat alles realtime op', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.22', 'Er kunnen gebruikers worden aangemaakt', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.22.1', 'Het systeem weergeeft een speciaal formulier hiervoor', 'Non-Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.22'),
('0.22.1.1', 'Het systeem accepteert een studentencode', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.22.1'),
('0.22.1.1.1', 'Het systeem kan uit een database de student halen die bij die code hoort', 'Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.22.1.1'),
('0.23', 'Het systeem is gemaakt in de programmeertaal c#', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.24', 'Het systeem maakt gebruik van een MySQL database', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.25', 'Het systeem maakt gebruik van het inlogsysteem van Avans', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.26', 'Het systeem is Object Georienteerd geschreven', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.27', 'Het systeem is geprogrammeerd met comments zodat de applicatie kan worden aangepast door verschillende programmeurs', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.28', 'Het systeem is gemaakt met een MVVM structuur', 'Technical', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.29', 'Het systeem kan worden benaderd door een browser', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.29.1', 'Browser = Internet Explorer Versie 8 of hoger', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.29'),
('0.29.2', 'Browser = Google Chrome versie 14 of hoger', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.29'),
('0.29.3', 'Browser = Mozilla firefox Versie 6 of hoger', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.29'),
('0.29.4', 'Browser = Safari Versie 3 of hoger', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.29'),
('0.30.', 'Het systeem maakt gebruik van een extern inlogsysteem', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.31', 'De anonimiteitsfactor in een beoordeling kan bepaald worden in het systeem', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.32', 'Het systeem kan gegevens ophalen uit een extern inlogsysteem ', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.33', 'Het systeem kan verbinding maken met een database', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.34', 'Het systeem kan emails versturen.', 'Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.35', 'Systeem kan op meerdere OSen draaien', 'Technical', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.36', 'Systeem kan duidelijke fout meldingen geven', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.36.1', 'De foutenmeldingen krijgen een ID per bepaalde fout', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.36'),
('0.36.1.1', 'De bekende fouten krijgen IDs ', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.36.1'),
('0.36.1.1.1', 'Het systeem geeft een fout als er geen verbinding is', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.36.1.1'),
('0.36.1.1.2', 'Het systeem geeft het aan als de inlog gegevens foutief zijn', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.36.1.1'),
('0.37', 'Het systeem kan met verschillende projecten werken', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.38', 'Het systeem kan makkelijk onderhouden worden', 'Technical', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.39', 'Het systeem heeft een GPL3 License', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.40.', 'Het systeem kan in de standaard browser geopend worden', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.41', 'Het systeem is <klantvriendlijk>', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.41.1', 'Het systeem heeft een rustige achtergrond', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.41'),
('0.41.2', 'het systeem heeft een <goed leesbaar lettertype>', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.41.2'),
('0.41.2.1', '<goed leesbaar lettertype> = Ariel, Helvetica', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.41.2'),
('0.41.3', 'Het systeem heeft duidelijk benamingen voor functies', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.41'),
('0.42', 'Het systeem kan aangepast worden aan de wensen van de gebruiker ', 'Functional', 'Unknown', 'Open', 'Laag', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.42.1', 'het systeem kan letters groter maken voor slecht zienden', 'Functional', 'Unknown', 'Open', 'Laag', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.42'),
('0.42.2', 'het systeem kan bestuurt worden zonder muis ', 'Non-Functional', 'Unknown', 'Open', 'Laag', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.42'),
('0.42.3', 'Het systeem kan makkelijk begrepen worden door iedereen', 'Non-Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.42'),
('0.43', 'Het systeem accepteert opmerkingen bij beoordelingen', 'Functional', 'Unknown', 'Open', 'Middel', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.44', 'Het systeem heeft verschillende user roles', 'Non-Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, NULL),
('0.44.1', 'Het systeem maakt onderscheid tussen de user roles', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.44'),
('0.44.1.1', 'Het systeem laat aan de hand van de user role de bijbehorende schermen zien', 'Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.44.1'),
('0.44.1.2', 'Het systeem heeft een role Student', 'Non-Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.44.1'),
('0.44.1.3', 'Het systeem heeft een role Tutor', 'Non-Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.44.1'),
('0.44.1.4', 'Het systeem heeft een role Mentor', 'Non-Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.44.1'),
('0.44.1.5', 'Het systeem heeft een role Docent', 'Non-Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.44.1'),
('0.44.1.6', 'Het systeem heeft een role Administrator', 'Non-Functional', 'Unknown', 'Open', 'Hoog', NULL, NULL, NULL, 'Group', NULL, NULL, NULL, '0.44.1'),
('1.1.1', 'Een project kan aangemaakt worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.1.1.1', 'Een begindatum van een project kan ingevoerd worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1'),
('1.1.1.1.1', 'Een begindatum wordt geselecteerd d.m.v. een kalender', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.1'),
('1.1.1.1.2', 'De begindatum moet in het huidige jaar liggen', 'Functional', 'Unknown', 'Open', 'Laag', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.1'),
('1.1.1.2', 'Een einddatum van een project kan ingevoerd worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1'),
('1.1.1.2.1', 'De einddatum mag niet meer dan een jaar van de huidige datum zijn', 'Functional', 'Unknown', 'Open', 'Laag', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.2'),
('1.1.1.2.2', 'De einddatum mag niet eerder dan de begindatum zijn', 'Functional', 'Unknown', 'Open', 'Middel', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.2'),
('1.1.1.2.3', 'Een einddatum wordt geselecteerd d.m.v. een kalender', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.2'),
('1.1.1.3', 'De beoordelingsmomenten kunnen ingevoegd worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1'),
('1.1.1.3.1', 'De beoordelingsmomenten worden geselecteerd d.m.v. een kalender', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.3'),
('1.1.1.3.2', 'Het aantal beoordelingsmomenten staat standaard op 3', 'Functional', 'Unknown', 'Open', 'Middel', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.3'),
('1.1.1.3.3', 'Het aantal beoordelingsmomenten kan aangepast worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.3'),
('1.1.1.4', 'Een projectnaam kan ingevoerd worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1'),
('1.1.1.5', 'Een groep van leerlingen kan toegevoegd worden aan een project', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1'),
('1.1.1.5.1', 'De groep van leerlingen kan geselecteerd worden uit een lijst', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.5'),
('1.1.1.5.2', 'De groep leerlingen kan handmatig gemaakt worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.5'),
('1.1.1.5.3', 'De groep leerlingen kan uit een excel sheet geïmporteerd worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1.5'),
('1.1.1.6', 'Een beoordelingstemplate kan toegevoegd worden aan een project', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1'),
('1.1.1.7', 'Een lijst met bestaande beoordelings templates kan getoond worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.1'),
('1.1.2', 'De informatie van een ingevuld formulier kan bevestigd worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.1.3', 'De informatie van een project kan opgeslagen worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.1.4', 'De informatie van een project kan opgehaald worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.1.5', 'De informatie van een project kan aangepast worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.1.6', 'Het systeem controleert de gegevens', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.1.6.1', 'Het systeem controleert of alle gegevens zijn ingevuld', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.6'),
('1.1.6.2', 'Het systeem geeft een melding als dit niet het geval is', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.6'),
('1.1.6.2.1', 'Zolang dit het geval is kan er niets bevestigd worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.1', NULL, 'Group', NULL, NULL, NULL, '1.1.6.2'),
('1.2.1', 'Een beoordelingstemplate kan aangemaakt worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.2', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.2.1.1', 'De subvragen kunnen worden gedefiniëerd', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.2', NULL, 'Group', NULL, NULL, NULL, '1.2.1'),
('1.2.1.2', 'De hoofdvragen worden standaard gedefiniëerd', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.2', NULL, 'Group', NULL, NULL, NULL, '1.2.1'),
('1.2.1.3', 'Standaard templates kunnen worden opgeslagen', 'Functional', 'Unknown', 'Open', 'Middel', '1', '1.2', NULL, 'Group', NULL, NULL, NULL, '1.2.1'),
('1.2.2', 'Beoordelingscriteria staan standaard op cijfers', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.2', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.2.3', 'Beoordelingscriteria kunnen aangepast worden naar <<O/V/G>>', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.2', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.2.3.1', 'O/V/G: Onvoldoende/Voldoende/Goed', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.2', NULL, 'Group', NULL, NULL, NULL, '1.2.3'),
('1.2.4', 'Het systeem kan een lijst met alle huidige en toekomstige projecten laten zien', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.3', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.2.4.1', 'Het systeem kan aangeven welke beoordelingen nog ingevuld moeten worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.3', NULL, 'Group', NULL, NULL, NULL, '1.2.4'),
('1.2.4.1.1', 'Het systeem kan beoordelingen sorteren op deadline', 'Functional', 'Unknown', 'Open', 'Middel', '1', '1.3', NULL, 'Group', NULL, NULL, NULL, '1.2.4.1'),
('1.2.4.2', 'Een project kan uit de lijst geselecteerd worden', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.3', NULL, 'Group', NULL, NULL, NULL, '1.2.4.1'),
('1.3.1', 'Groepen kunnen geïmporteerd worden door middel van een excelsheet', 'Functional', 'Unknown', 'Open', 'Hoog', '1', '1.3', NULL, 'Group', NULL, NULL, NULL, NULL),
('1.3.1.1', 'Het systeem kan het excel sheet controleren op syntaxfouten', 'Functional', 'Unknown', 'Open', 'Middel', '1', '1.3', NULL, 'Group', NULL, NULL, NULL, '1.3.1'),
('1.3.1.1.1', 'Het systeem geeft een melding of de excel sheet succesvol is geïmporteerd', 'Functional', 'Unknown', 'Open', 'Middel', '1', '1.3', NULL, 'Group', NULL, NULL, NULL, '1.3.1.1'),
('1.3.1.1.2', 'Het systeem geeft een melding of de excel sheet fouten bevat', 'Functional', 'Unknown', 'Open', 'Middel', '1', '1.3', NULL, 'Group', NULL, NULL, NULL, '1.3.1.1'),
('2.1.1', 'Het systeem kan een lijst van beoordelingsmiddelen weergeven', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('2.1.2', 'Het systeem kan een lijst van studenten behorend bij het beoordelingsmiddel laten zien', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('2.1.3', 'Het systeem accepteert meerdere beoordelingsmethodes', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('2.1.3.1', 'Het systeem accepteert cijfers als beoordelingsmethode', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, '2.1.3'),
('2.1.3.2', 'Het systeem accepteert <"O">, <"V"> <"G"> als beoordelingsmethode', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, '2.1.3'),
('2.1.3.2.1', '<"O"> = 4', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, '2.1.3.2'),
('2.1.3.2.2', '<"V"> = 7', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, '2.1.3.2'),
('2.1.3.2.3', '<"G"> = 10', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, '2.1.3.2'),
('2.1.4', 'Het systeem kan valideren of elk veld bij een beoordeling <<juist>> is ingevuld', 'Functional', 'Unknown', 'Open', 'Middel', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('2.1.4.1', 'Juist: Cijfers mogen niet hoger zijn dan 10', 'Functional', 'Unknown', 'Open', 'Middel', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, '2.1.4'),
('2.1.4.2', 'Juist: Een veld mag niet leeg zijn', 'Functional', 'Unknown', 'Open', 'Middel', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, '2.1.4'),
('2.1.4.3', 'Juist: een cijfer moet 1 of hoger zijn', 'Functional', 'Unknown', 'Open', 'Middel', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, '2.1.4'),
('2.1.5', 'Het systeem geeft een melding als een beoordeling niet <<juist>> is ingevuld', 'Functional', 'Unknown', 'Open', 'Middel', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('2.1.6', 'Het systeem kan beoordelingen opslaan', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('2.1.7', 'Het systeem kan met kleuren weergeven wanneer een beoordeling voldoende is of niet.', 'Functional', 'Unknown', 'Open', 'Hoog', '2', '2.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('3.1.1', 'Het systeem laat beoordelingen zien van afgelopen weken', 'Functional', 'Unknown', 'Open', 'Hoog', '3', '3.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('3.1.2', 'Het systeem kan het gemiddelde laten zien van alle beoordeelde weken ', 'Functional', 'Unknown', 'Open', 'Hoog', '3', '3.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('3.1.2.1', 'Het systeem kan een gemiddelde berekenen', 'Functional', 'Unknown', 'Open', 'Laag', '3', '3.1', NULL, 'Group', NULL, NULL, NULL, '3.1.2'),
('3.1.3', 'Het systeem kan laten zien of studenten hun beoordeling hebben ingevuld', 'Functional', 'Unknown', 'Open', 'Hoog', '3', '3.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('4.1.1', 'Het systeem kan een student zoeken', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('4.1.2', 'Het systeem kan alle beoordelingen ophalen van een student', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.1', NULL, 'Group', NULL, NULL, NULL, NULL),
('4.1.2.1', 'Het systeem kan beoordelingen samenvoegen', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.1', NULL, 'Group', NULL, NULL, NULL, '4.1.2'),
('4.1.2.1.1', 'Het systeem moet een beoordeling van een student kunnen opzoeken', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.1', NULL, 'Group', NULL, NULL, NULL, '4.1.2.1'),
('4.2.1', 'Een historisch overzicht van een student kan opgevraagd worden', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.2', NULL, 'Group', NULL, NULL, NULL, NULL),
('4.2.1.1', 'Het systeem kan een overzicht creëren. ', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.2', NULL, 'Group', NULL, NULL, NULL, '4.2.1'),
('4.2.2', 'Het systeem kan een excelsheet genereren', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.2', NULL, 'Group', NULL, NULL, NULL, NULL),
('4.2.3', 'Het systeem kan een excelsheet exporteren', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.2', NULL, 'Group', NULL, NULL, NULL, NULL),
('4.2.4', 'Het systeem kan een overzicht in een grafiek weergeven.', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.2', NULL, 'Group', NULL, NULL, NULL, NULL),
('4.2.4.1', 'Het systeem kan een grafiek tekenen', 'Functional', 'Unknown', 'Open', 'Hoog', '4', '4.2', NULL, 'Group', NULL, NULL, NULL, '4.2.4');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Requirement_Conflict`
--

CREATE TABLE IF NOT EXISTS `Requirement_Conflict` (
  `RC_id` varchar(11) NOT NULL,
  `RC_Requirement_id` varchar(11) NOT NULL,
  `RC_Conflict_Requirement` varchar(11) NOT NULL,
  PRIMARY KEY (`RC_id`),
  UNIQUE KEY `RC_id_UNIQUE` (`RC_id`),
  KEY `rc_req_fk_idx` (`RC_Requirement_id`),
  KEY `rc_req_2_fk_idx` (`RC_Conflict_Requirement`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Stakeholder`
--

CREATE TABLE IF NOT EXISTS `Stakeholder` (
  `SH_id` int(11) NOT NULL,
  `SH_naam` varchar(45) NOT NULL,
  `SH_beschrijving` varchar(45) NOT NULL,
  PRIMARY KEY (`SH_id`),
  UNIQUE KEY `SH_id_UNIQUE` (`SH_id`),
  UNIQUE KEY `SH_naam_UNIQUE` (`SH_naam`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `Stakeholder`
--

INSERT INTO `Stakeholder` (`SH_id`, `SH_naam`, `SH_beschrijving`) VALUES
(1, 'Student', 'Die ene die het project uitvoert'),
(2, 'Tutor', 'Docent die het groep begleid'),
(3, 'Projectdocent', 'Beheerder van het project'),
(4, 'Docent', 'Persoon die de lessen geeft'),
(5, 'Mentor', 'Begeleider van de student'),
(6, 'Examencommissie', 'De mensen die beslissingingen nemen over beoo');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Status`
--

CREATE TABLE IF NOT EXISTS `Status` (
  `sta_naam` varchar(45) NOT NULL,
  `sta_beschrijving` varchar(45) NOT NULL,
  PRIMARY KEY (`sta_naam`),
  UNIQUE KEY `sta_naam_UNIQUE` (`sta_naam`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `Status`
--

INSERT INTO `Status` (`sta_naam`, `sta_beschrijving`) VALUES
('Open', 'Nog niks aan gedaan');

--
-- Beperkingen voor gedumpte tabellen
--

--
-- Beperkingen voor tabel `BUC_Betrokken_Stakeholder`
--
ALTER TABLE `BUC_Betrokken_Stakeholder`
  ADD CONSTRAINT `BUCBS_BUC_fk` FOREIGN KEY (`BUCBS_BUC_id`) REFERENCES `Business_Use_Case` (`BUC_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `BUCBS_SH_fk` FOREIGN KEY (`BUCBS_stakeholder`) REFERENCES `Stakeholder` (`SH_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `BUC_Geintereseerde_Stakeholder`
--
ALTER TABLE `BUC_Geintereseerde_Stakeholder`
  ADD CONSTRAINT `BUCGS_BUC_fk` FOREIGN KEY (`BUCGS_BUC_id`) REFERENCES `Business_Use_Case` (`BUC_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `BUCGS_SH_fk` FOREIGN KEY (`BUCGS_stakeholder`) REFERENCES `Stakeholder` (`SH_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `BUC_Stapsgewijs_Beschrijving`
--
ALTER TABLE `BUC_Stapsgewijs_Beschrijving`
  ADD CONSTRAINT `SB_BUC_fk` FOREIGN KEY (`SB_id`) REFERENCES `Business_Use_Case` (`BUC_stapsgewijs_beschrijving`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `Product_Use_Case`
--
ALTER TABLE `Product_Use_Case`
  ADD CONSTRAINT `PUC_BUC_fk` FOREIGN KEY (`BUC_naam`) REFERENCES `Business_Use_Case` (`BUC_naam`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `PUC_BUC_id_fk` FOREIGN KEY (`BUC_id`) REFERENCES `Business_Use_Case` (`BUC_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `PUC_Actoren`
--
ALTER TABLE `PUC_Actoren`
  ADD CONSTRAINT `PUCA_A_fk` FOREIGN KEY (`PUCA_A_id`) REFERENCES `Actor` (`A_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `PUCA_PUC_fk` FOREIGN KEY (`PUCA_PUC_id`) REFERENCES `Product_Use_Case` (`PUC_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `PUC_Stakeholder`
--
ALTER TABLE `PUC_Stakeholder`
  ADD CONSTRAINT `PUCS_PUC_fk` FOREIGN KEY (`PUCS_PUC_id`) REFERENCES `Product_Use_Case` (`PUC_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `PUCS_SH_fk` FOREIGN KEY (`PUCS_stakeholder`) REFERENCES `Stakeholder` (`SH_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `PUC_Stapsgewijs_Beschrijving`
--
ALTER TABLE `PUC_Stapsgewijs_Beschrijving`
  ADD CONSTRAINT `SB_PUC_fk` FOREIGN KEY (`SB_id`) REFERENCES `Product_Use_Case` (`PUC_stapsgewijs_beschrijving`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `Requirement`
--
ALTER TABLE `Requirement`
  ADD CONSTRAINT `req_buc_fk` FOREIGN KEY (`req_BUC`) REFERENCES `Business_Use_Case` (`BUC_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `req_cat_fk` FOREIGN KEY (`req_catagorie`) REFERENCES `Catagorie` (`cat_naam`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `req_fun_fk` FOREIGN KEY (`req_functie`) REFERENCES `Functie` (`fun_naam`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `req_pri_fk` FOREIGN KEY (`req_prioriteit`) REFERENCES `Prioriteit` (`pri_naam`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `req_puc_fk` FOREIGN KEY (`req_PUC`) REFERENCES `Product_Use_Case` (`PUC_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `req_req_1_fk` FOREIGN KEY (`req_is_subreq_van`) REFERENCES `Requirement` (`req_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `req_sta_fk` FOREIGN KEY (`req_status`) REFERENCES `Status` (`sta_naam`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `Requirement_Conflict`
--
ALTER TABLE `Requirement_Conflict`
  ADD CONSTRAINT `rc_req_2_fk` FOREIGN KEY (`RC_Conflict_Requirement`) REFERENCES `Requirement` (`req_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `rc_req_fk` FOREIGN KEY (`RC_Requirement_id`) REFERENCES `Requirement` (`req_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
