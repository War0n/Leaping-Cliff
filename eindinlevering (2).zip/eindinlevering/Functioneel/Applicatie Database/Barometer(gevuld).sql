-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 27 okt 2013 om 16:11
-- Serverversie: 5.5.31
-- PHP-Versie: 5.4.4-14+deb7u5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `Barometer`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Cijfer`
--

CREATE TABLE IF NOT EXISTS `Cijfer` (
  `id_Cijfer` int(11) NOT NULL,
  `vraag` varchar(45) NOT NULL,
  `cijfer` decimal(2,0) NOT NULL,
  `door_student` int(11) NOT NULL,
  `voor_student` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id_Cijfer`),
  UNIQUE KEY `id_Cijfer_UNIQUE` (`id_Cijfer`),
  KEY `fk_Cijfer_Student1_idx` (`door_student`),
  KEY `fk_Cijfer_Student2_idx` (`voor_student`),
  KEY `fk_Cijfer_Project1_idx` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden uitgevoerd voor tabel `Cijfer`
--

INSERT INTO `Cijfer` (`id_Cijfer`, `vraag`, `cijfer`, `door_student`, `voor_student`, `project_id`) VALUES
(1, 'Is deze student goed in programmeren?', 1, 1, 2, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Mentor`
--

CREATE TABLE IF NOT EXISTS `Mentor` (
  `mentor_id` int(11) NOT NULL,
  `mentor_naam` varchar(45) NOT NULL,
  PRIMARY KEY (`mentor_id`),
  UNIQUE KEY `mentor_id_UNIQUE` (`mentor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden uitgevoerd voor tabel `Mentor`
--

INSERT INTO `Mentor` (`mentor_id`, `mentor_naam`) VALUES
(1, 'Jasper van Rosmalen');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Project`
--

CREATE TABLE IF NOT EXISTS `Project` (
  `project_id` int(11) NOT NULL,
  `project_beschrijving` varchar(165) NOT NULL,
  `project_tutors` int(11) NOT NULL,
  `project_groepen` int(11) NOT NULL,
  `project_begindatum` date DEFAULT NULL,
  `project_einddatum` date DEFAULT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden uitgevoerd voor tabel `Project`
--

INSERT INTO `Project` (`project_id`, `project_beschrijving`, `project_tutors`, `project_groepen`, `project_begindatum`, `project_einddatum`) VALUES
(1, 'Project Barometer', 1, 1, '2013-01-01', '2014-01-01');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Projectgroep`
--

CREATE TABLE IF NOT EXISTS `Projectgroep` (
  `projectgroep_id` int(11) NOT NULL,
  `projectgroep_studenten` int(11) NOT NULL,
  `tutor_id` int(11) NOT NULL,
  PRIMARY KEY (`projectgroep_id`),
  UNIQUE KEY `projectgroep_id_UNIQUE` (`projectgroep_id`),
  KEY `fk_Projectgroep_Tutor1_idx` (`tutor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden uitgevoerd voor tabel `Projectgroep`
--

INSERT INTO `Projectgroep` (`projectgroep_id`, `projectgroep_studenten`, `tutor_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Projectgroep_Studenten`
--

CREATE TABLE IF NOT EXISTS `Projectgroep_Studenten` (
  `projectgroep_studenten_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `projectgroep_id` int(11) NOT NULL,
  PRIMARY KEY (`projectgroep_studenten_id`),
  KEY `fk_Projectgroep_Studenten_Student1_idx` (`student_id`),
  KEY `fk_Projectgroep_Studenten_Projectgroep1_idx` (`projectgroep_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden uitgevoerd voor tabel `Projectgroep_Studenten`
--

INSERT INTO `Projectgroep_Studenten` (`projectgroep_studenten_id`, `student_id`, `projectgroep_id`) VALUES
(1, 1, 1),
(2, 2, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Project_Projectgroepen`
--

CREATE TABLE IF NOT EXISTS `Project_Projectgroepen` (
  `proj_stud_id` int(11) NOT NULL,
  `proj_gr_id` int(11) NOT NULL,
  `proj_id` int(11) NOT NULL,
  PRIMARY KEY (`proj_stud_id`),
  KEY `fk_Project_Projectgroepen_Projectgroep1_idx` (`proj_gr_id`),
  KEY `fk_Project_Projectgroepen_Project1_idx` (`proj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden uitgevoerd voor tabel `Project_Projectgroepen`
--

INSERT INTO `Project_Projectgroepen` (`proj_stud_id`, `proj_gr_id`, `proj_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Project_Tutor`
--

CREATE TABLE IF NOT EXISTS `Project_Tutor` (
  `proj_tutor_id` int(11) NOT NULL,
  `proj_id` int(11) NOT NULL,
  `tut_id` int(11) NOT NULL,
  PRIMARY KEY (`proj_tutor_id`),
  KEY `fk_Project_Tutor_Project1_idx` (`proj_id`),
  KEY `fk_Project_Tutor_Tutor1_idx` (`tut_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden uitgevoerd voor tabel `Project_Tutor`
--

INSERT INTO `Project_Tutor` (`proj_tutor_id`, `proj_id`, `tut_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Student`
--

CREATE TABLE IF NOT EXISTS `Student` (
  `student_id` int(11) NOT NULL,
  `student_naam` varchar(45) NOT NULL,
  `student_mentor` int(11) NOT NULL,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `student_id_UNIQUE` (`student_id`),
  KEY `fk_Student_Mentor_idx` (`student_mentor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden uitgevoerd voor tabel `Student`
--

INSERT INTO `Student` (`student_id`, `student_naam`, `student_mentor`) VALUES
(1, 'Nick vd Meij', 1),
(2, 'Dennis Dolman', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Tutor`
--

CREATE TABLE IF NOT EXISTS `Tutor` (
  `tutor_id` int(11) NOT NULL,
  `tutor_naam` varchar(45) NOT NULL,
  PRIMARY KEY (`tutor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden uitgevoerd voor tabel `Tutor`
--

INSERT INTO `Tutor` (`tutor_id`, `tutor_naam`) VALUES
(1, 'Marieke Versteijlen'),
(2, 'Bob Bus'),
(3, 'Erik van Appeldoorn');

--
-- Beperkingen voor gedumpte tabellen
--

--
-- Beperkingen voor tabel `Cijfer`
--
ALTER TABLE `Cijfer`
  ADD CONSTRAINT `fk_Cijfer_Student1` FOREIGN KEY (`door_student`) REFERENCES `Student` (`student_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Cijfer_Student2` FOREIGN KEY (`voor_student`) REFERENCES `Student` (`student_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Cijfer_Project1` FOREIGN KEY (`project_id`) REFERENCES `Project` (`project_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `Projectgroep`
--
ALTER TABLE `Projectgroep`
  ADD CONSTRAINT `fk_Projectgroep_Tutor1` FOREIGN KEY (`tutor_id`) REFERENCES `Tutor` (`tutor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `Projectgroep_Studenten`
--
ALTER TABLE `Projectgroep_Studenten`
  ADD CONSTRAINT `fk_Projectgroep_Studenten_Student1` FOREIGN KEY (`student_id`) REFERENCES `Student` (`student_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Projectgroep_Studenten_Projectgroep1` FOREIGN KEY (`projectgroep_id`) REFERENCES `Projectgroep` (`projectgroep_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `Project_Projectgroepen`
--
ALTER TABLE `Project_Projectgroepen`
  ADD CONSTRAINT `fk_Project_Projectgroepen_Projectgroep1` FOREIGN KEY (`proj_gr_id`) REFERENCES `Projectgroep` (`projectgroep_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Project_Projectgroepen_Project1` FOREIGN KEY (`proj_id`) REFERENCES `Project` (`project_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `Project_Tutor`
--
ALTER TABLE `Project_Tutor`
  ADD CONSTRAINT `fk_Project_Tutor_Project1` FOREIGN KEY (`proj_id`) REFERENCES `Project` (`project_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Project_Tutor_Tutor1` FOREIGN KEY (`tut_id`) REFERENCES `Tutor` (`tutor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `Student`
--
ALTER TABLE `Student`
  ADD CONSTRAINT `fk_Student_Mentor` FOREIGN KEY (`student_mentor`) REFERENCES `Mentor` (`mentor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
