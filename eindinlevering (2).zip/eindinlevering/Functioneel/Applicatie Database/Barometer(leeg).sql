SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

DROP SCHEMA IF EXISTS `Barometer` ;
CREATE SCHEMA IF NOT EXISTS `Barometer` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `Barometer` ;

-- -----------------------------------------------------
-- Table `Barometer`.`Mentor`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Barometer`.`Mentor` ;

CREATE TABLE IF NOT EXISTS `Barometer`.`Mentor` (
  `mentor_id` INT NOT NULL,
  `mentor_naam` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`mentor_id`))
ENGINE = InnoDB;

CREATE UNIQUE INDEX `mentor_id_UNIQUE` ON `Barometer`.`Mentor` (`mentor_id` ASC);


-- -----------------------------------------------------
-- Table `Barometer`.`Student`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Barometer`.`Student` ;

CREATE TABLE IF NOT EXISTS `Barometer`.`Student` (
  `student_id` INT NOT NULL,
  `student_naam` VARCHAR(45) NOT NULL,
  `student_mentor` INT NOT NULL,
  PRIMARY KEY (`student_id`),
  CONSTRAINT `fk_Student_Mentor`
    FOREIGN KEY (`student_mentor`)
    REFERENCES `Barometer`.`Mentor` (`mentor_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE UNIQUE INDEX `student_id_UNIQUE` ON `Barometer`.`Student` (`student_id` ASC);

CREATE INDEX `fk_Student_Mentor_idx` ON `Barometer`.`Student` (`student_mentor` ASC);


-- -----------------------------------------------------
-- Table `Barometer`.`Tutor`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Barometer`.`Tutor` ;

CREATE TABLE IF NOT EXISTS `Barometer`.`Tutor` (
  `tutor_id` INT NOT NULL,
  `tutor_naam` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`tutor_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Barometer`.`Projectgroep`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Barometer`.`Projectgroep` ;

CREATE TABLE IF NOT EXISTS `Barometer`.`Projectgroep` (
  `projectgroep_id` INT NOT NULL,
  `projectgroep_studenten` INT NOT NULL,
  `tutor_id` INT NOT NULL,
  PRIMARY KEY (`projectgroep_id`),
  CONSTRAINT `fk_Projectgroep_Tutor1`
    FOREIGN KEY (`tutor_id`)
    REFERENCES `Barometer`.`Tutor` (`tutor_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE UNIQUE INDEX `projectgroep_id_UNIQUE` ON `Barometer`.`Projectgroep` (`projectgroep_id` ASC);

CREATE INDEX `fk_Projectgroep_Tutor1_idx` ON `Barometer`.`Projectgroep` (`tutor_id` ASC);


-- -----------------------------------------------------
-- Table `Barometer`.`Projectgroep_Studenten`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Barometer`.`Projectgroep_Studenten` ;

CREATE TABLE IF NOT EXISTS `Barometer`.`Projectgroep_Studenten` (
  `projectgroep_studenten_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  `projectgroep_id` INT NOT NULL,
  PRIMARY KEY (`projectgroep_studenten_id`),
  CONSTRAINT `fk_Projectgroep_Studenten_Student1`
    FOREIGN KEY (`student_id`)
    REFERENCES `Barometer`.`Student` (`student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Projectgroep_Studenten_Projectgroep1`
    FOREIGN KEY (`projectgroep_id`)
    REFERENCES `Barometer`.`Projectgroep` (`projectgroep_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_Projectgroep_Studenten_Student1_idx` ON `Barometer`.`Projectgroep_Studenten` (`student_id` ASC);

CREATE INDEX `fk_Projectgroep_Studenten_Projectgroep1_idx` ON `Barometer`.`Projectgroep_Studenten` (`projectgroep_id` ASC);


-- -----------------------------------------------------
-- Table `Barometer`.`Project`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Barometer`.`Project` ;

CREATE TABLE IF NOT EXISTS `Barometer`.`Project` (
  `project_id` INT NOT NULL,
  `project_beschrijving` VARCHAR(165) NOT NULL,
  `project_tutors` INT NOT NULL,
  `project_groepen` INT NOT NULL,
  `project_begindatum` DATE NULL,
  `project_einddatum` DATE NULL,
  PRIMARY KEY (`project_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Barometer`.`Project_Projectgroepen`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Barometer`.`Project_Projectgroepen` ;

CREATE TABLE IF NOT EXISTS `Barometer`.`Project_Projectgroepen` (
  `proj_stud_id` INT NOT NULL,
  `proj_gr_id` INT NOT NULL,
  `proj_id` INT NOT NULL,
  PRIMARY KEY (`proj_stud_id`),
  CONSTRAINT `fk_Project_Projectgroepen_Projectgroep1`
    FOREIGN KEY (`proj_gr_id`)
    REFERENCES `Barometer`.`Projectgroep` (`projectgroep_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Project_Projectgroepen_Project1`
    FOREIGN KEY (`proj_id`)
    REFERENCES `Barometer`.`Project` (`project_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_Project_Projectgroepen_Projectgroep1_idx` ON `Barometer`.`Project_Projectgroepen` (`proj_gr_id` ASC);

CREATE INDEX `fk_Project_Projectgroepen_Project1_idx` ON `Barometer`.`Project_Projectgroepen` (`proj_id` ASC);


-- -----------------------------------------------------
-- Table `Barometer`.`Project_Tutor`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Barometer`.`Project_Tutor` ;

CREATE TABLE IF NOT EXISTS `Barometer`.`Project_Tutor` (
  `proj_tutor_id` INT NOT NULL,
  `proj_id` INT NOT NULL,
  `tut_id` INT NOT NULL,
  PRIMARY KEY (`proj_tutor_id`),
  CONSTRAINT `fk_Project_Tutor_Project1`
    FOREIGN KEY (`proj_id`)
    REFERENCES `Barometer`.`Project` (`project_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Project_Tutor_Tutor1`
    FOREIGN KEY (`tut_id`)
    REFERENCES `Barometer`.`Tutor` (`tutor_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_Project_Tutor_Project1_idx` ON `Barometer`.`Project_Tutor` (`proj_id` ASC);

CREATE INDEX `fk_Project_Tutor_Tutor1_idx` ON `Barometer`.`Project_Tutor` (`tut_id` ASC);


-- -----------------------------------------------------
-- Table `Barometer`.`Cijfer`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Barometer`.`Cijfer` ;

CREATE TABLE IF NOT EXISTS `Barometer`.`Cijfer` (
  `id_Cijfer` INT NOT NULL,
  `vraag` VARCHAR(45) NOT NULL,
  `cijfer` DECIMAL(2) NOT NULL,
  `door_student` INT NOT NULL,
  `voor_student` INT NOT NULL,
  `project_id` INT NOT NULL,
  PRIMARY KEY (`id_Cijfer`),
  CONSTRAINT `fk_Cijfer_Student1`
    FOREIGN KEY (`door_student`)
    REFERENCES `Barometer`.`Student` (`student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Cijfer_Student2`
    FOREIGN KEY (`voor_student`)
    REFERENCES `Barometer`.`Student` (`student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Cijfer_Project1`
    FOREIGN KEY (`project_id`)
    REFERENCES `Barometer`.`Project` (`project_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE UNIQUE INDEX `id_Cijfer_UNIQUE` ON `Barometer`.`Cijfer` (`id_Cijfer` ASC);

CREATE INDEX `fk_Cijfer_Student1_idx` ON `Barometer`.`Cijfer` (`door_student` ASC);

CREATE INDEX `fk_Cijfer_Student2_idx` ON `Barometer`.`Cijfer` (`voor_student` ASC);

CREATE INDEX `fk_Cijfer_Project1_idx` ON `Barometer`.`Cijfer` (`project_id` ASC);


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
